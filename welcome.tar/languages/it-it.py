{
'Hello World':'Salve Mondo',
'Welcome to web2py':'Ciao da wek2py',
}
