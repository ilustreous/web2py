{
'%Y-%m-%d':'%Y-%m-%d',
'%Y-%m-%d %H:%M:%S':'%Y-%m-%d %H:%M:%S',
'%s rows deleted':'%s records cancellati',
'%s rows updated':'*** %s records modificati',
'Hello World':'Salve Mondo',
'Invalid Query':'Query invalida',
'Sure you want to delete this object?':'Sicuro che vuoi cancellare questo oggetto?',
'Welcome to web2py':'Ciao da wek2py',
'click here for online examples':'clicca per vedere gli esempi',
'click here for the administrative interface':'clicca per l\'interfaccia administrativa',
'data uploaded':'dati caricati',
'db':'db',
'design':'progetta',
'done!':'fatto!',
'invalid request':'richiesta invalida!'
'new record inserted':'nuovo record inserito'
'record does not exist':'il record non esiste'
'state':'stato',
'unable to parse csv file':'non so leggere questo csv file'
}
