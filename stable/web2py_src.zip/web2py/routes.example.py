routes_in=(
('.*:/favicon.ico','/examples/static/favicon.ico'),
('.*:/robots.txt','/examples/static/robots.txt'),
)

routes_out=()