#!/bin/python2.5

import gluon.import_all
from gluon.widget import start
start()